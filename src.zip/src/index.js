const { scrapeInstagram } = require('./scrapers/instagram');
const { scrapeFacebook } = require('./scrapers/facebook');
const { scrapeTikTok } = require('./scrapers/tiktok');

(async () => {
  console.log(await scrapeInstagram('somehandle'));
  console.log(await scrapeFacebook('someusername'));
  console.log(await scrapeTikTok('somehandle'));
})();
