// scrapers/facebook.js
const puppeteer = require('puppeteer');

async function scrapeFacebook(handle) {
  const browser = await puppeteer.launch({ headless: true });
  const page = await browser.newPage();

  // Facebook login required for most profiles
  await page.goto('https://www.facebook.com/login');
  await page.type('#email', process.env.FB_USER);
  await page.type('#pass', process.env.FB_PASS);
  await Promise.all([
    page.click('[name="login"]'),
    page.waitForNavigation(),
  ]);

  await page.goto(`https://www.facebook.com/${handle}`, { waitUntil: 'networkidle2' });

  const posts = await page.evaluate(() => {
    const results = [];
    document.querySelectorAll('[data-ad-preview="message"]').forEach(post => {
      results.push({
        text: post.innerText,
      });
    });
    return results;
  });

  await browser.close();
  return posts.slice(0, 5);
}

module.exports = { scrapeFacebook };
