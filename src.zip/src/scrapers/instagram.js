// scrapers/instagram.js
const puppeteer = require('puppeteer');

async function scrapeInstagram(handle) {
  const browser = await puppeteer.launch({ headless: true });
  const page = await browser.newPage();

  // Optional: log in to see private posts if you have credentials
  // await page.goto('https://www.instagram.com/accounts/login/');
  // await page.type('input[name="username"]', process.env.INSTAGRAM_USER);
  // await page.type('input[name="password"]', process.env.INSTAGRAM_PASS);
  // await page.click('button[type="submit"]');
  // await page.waitForNavigation();

  await page.goto(`https://www.instagram.com/${handle}/`, { waitUntil: 'networkidle2' });

  // Scrape post captions & image URLs (basic)
  const posts = await page.evaluate(() => {
    const nodes = document.querySelectorAll('article a');
    const results = [];
    nodes.forEach(node => {
      results.push({
        postUrl: 'https://www.instagram.com' + node.getAttribute('href'),
      });
    });
    return results;
  });

  await browser.close();
  return posts.slice(0, 10); // return top 10
}

module.exports = { scrapeInstagram };
