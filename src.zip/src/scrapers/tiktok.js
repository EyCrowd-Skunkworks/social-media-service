// scrapers/tiktok.js
const puppeteer = require('puppeteer');

async function scrapeTikTok(handle) {
  const browser = await puppeteer.launch({ headless: true });
  const page = await browser.newPage();

  await page.goto(`https://www.tiktok.com/@${handle}`, {
    waitUntil: 'networkidle2',
  });

  const posts = await page.evaluate(() => {
    const results = [];
    document.querySelectorAll('div[data-e2e="user-post-item"]').forEach(el => {
      const video = el.querySelector('a');
      const url = video ? video.href : null;
      results.push({ postUrl: url });
    });
    return results;
  });

  await browser.close();
  return posts.slice(0, 10);
}

module.exports = { scrapeTikTok };
